package com.transport.system.dao;

import com.transport.system.model.Role;
import com.transport.system.model.User;

import java.util.Date;
import java.util.List;

public class RoleDao {






}
